using System.Collections;
using UnityEngine;

public class PlayerController : MonoBehaviour
{

    [SerializeField] float speed = 1;
    [SerializeField] float rotateSpeed = 1;
    float rollAngle = 0;
    Vector3 offset = new Vector3(0, -5, 20);
    Vector3 screenCenter = new Vector3(Screen.width / 2f, Screen.height / 2f);
    void Start()
    {
    }

    void Update()
    {
        Vector3 mousePos = Input.mousePosition - screenCenter;
        Vector3 mouseOffset = new Vector3(mousePos.x,  mousePos.y+offset.y, offset.z);
        float horizontalMove = mouseOffset.x / screenCenter.x * rotateSpeed * Time.deltaTime;
        float verticalMove = -mouseOffset.y / screenCenter.y * rotateSpeed * Time.deltaTime;
        if (Input.mousePosition.x > Screen.width * 0.85f && rollAngle < 500 && rollAngle > -500)
            rollAngle += 1f;
        else if (Input.mousePosition.x < Screen.width * 0.15f && rollAngle < 500 && rollAngle > -500)
            rollAngle -= 1f;
        else rollAngle = 0f;
            transform.Rotate(verticalMove, horizontalMove, rollAngle * Time.deltaTime);

        //Vector3 lookDirection = new Vector3(mouseOffset.x, mouseOffset.y, offset.z);
        //Quaternion rotation = Quaternion.LookRotation(lookDirection.normalized, Vector3.up);
        //transform.rotation = Quaternion.Slerp(transform.rotation, rotation * Quaternion.Euler(0, rollAngle, 0), rotateSpeed*Time.deltaTime);
        transform.Translate(0, 0, speed * Time.deltaTime);
    }
}
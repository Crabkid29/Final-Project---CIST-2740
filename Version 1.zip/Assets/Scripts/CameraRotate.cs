using UnityEngine;

public class CameraRotate : MonoBehaviour
{
    [SerializeField] Transform jet;
    [SerializeField] float followSpeed = 1.0f;

    Vector3 offset = new Vector3(0, -5, 20);
    void LateUpdate()
    {
        transform.position = jet.position - jet.rotation * offset;
        transform.rotation = Quaternion.Slerp(transform.rotation, jet.rotation, followSpeed*Time.deltaTime);
    }    
}